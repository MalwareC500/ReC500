var fs = require('fs');
var kafka = require('kafka-node');

var Consumer = kafka.Consumer;

var client = new kafka.KafkaClient({ kafkaHost: '10.99.3.181:9092' });
var consumer = new kafka.Consumer(
    client,
    [
        { topic: 'RawMSDNSLog', partition: 0 }
    ],
    {
        autoCommit: false
    }
);


var producer = new kafka.ighLevelProducer(client);

var fields = ["date", "time", "c_ip", "c_port", "query_name", "query_class", "query_type", "query_flags"];

var fields2 = ["date", "time", "query_class", "query_class", "query_class", "c_ip", "c_ip", "query_type", "query_type", "query_type", "query_type", "query_name"];

var regex = /^(\S+) (\S+ AM|PM) ([0-9A-Z]{3,4}) (PACKET  [0-9A-Za-z]{8,16}) (UDP|TCP) (Snd|Rcv) (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) .* ([0-9a-z]{4}) .* (.*) \[(.*)\] (\S+?) .* (.*)/


consumer.on('message', function (log) {

    log = log.trim();

    if (log.length < 5) continue;

    var parsed = log.split(regex);

    //console.log(parsed);

    parsed.splice(0, 1);
    parsed.splice(parsed.length - 1, 1);

    var result = {};

    //console.log(log);

    for (var i = 0; i < fields.length; i++) {
        result[fields[i]] = null;
    }
    for (var i = 0; i < fields2.length; i++) {
        result[fields2[i]] = parsed[i];
    }
    payloads = [
        { topic: 'TreatetDNSLog', messages: result },
    ];
    producer.on('ready', function () {
        producer.send(payloads, function (data, err) {
            console.log(data);
        });
    });
});
