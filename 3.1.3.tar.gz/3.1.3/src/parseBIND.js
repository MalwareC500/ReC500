var fs = require('fs');
var kafka = require('kafka-node');

var client = new kafka.KafkaClient({ kafkaHost: '10.99.3.181:9092' });
var consumer = new kafka.Consumer(
    client,
    [
        { topic: 'RawBINDLog', partition: 0 }
    ],
    {
        autoCommit: false
    }
);


var producer = new kafka.ighLevelProducer(client);

var fields = ["date", "time", "c_ip", "c_port", "query_name", "query_class", "query_type", "query_flags"];

var regex = /^(\S+) (\S+) client (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})#(\d{1,5}) \(\S+\): query: (\S+) (\S+) (\S+) (\S+) \(\S+\)$/;

consumer.on('message', function (log) {

    log = log.trim();

    var parsed = log.split(regex);

    //console.log(parsed);

    parsed.splice(0, 1);
    parsed.splice(parsed.length - 1, 1);

    var result = {};

    //console.log(log);

    for (var i = 0; i < fields.length; i++) {
        result[fields[i]] = parsed[i];
    }
    payloads = [
        { topic: 'TreatetDNSLog', messages: result },
    ];
    producer.on('ready', function () {
        producer.send(payloads, function (data, err) {
            console.log(data);
        });
    });
});
