var fs = require('fs');
var kafka = require('kafka-node');

var Consumer = kafka.Consumer;

var client = new kafka.KafkaClient({ kafkaHost: '10.99.3.181:9092' });
var consumer = new kafka.Consumer(
    client,
    [
        { topic: 'RawIISLog', partition: 0 }
    ],
    {
        autoCommit: false
    }
);


var producer = new kafka.ighLevelProducer(client);

var fields = ["date", "time", "s_sitename", "s_computername", "server_ip", "cs_method", "cs_uri_stem", "cs_uri_query", "s_port", "cs_username", "c_ip", "cs_version", "cs_User_Agent", "cs_cookie", "cs_referer", "cs_host", "sc_status", "sc_substatus", "sc_win32_status", "sc_bytes", "cs_bytes", "time_taken"];

var regex = /^(\S+) (\S+) (\S+) (\S+) (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) (\S+) (\S+) (\S+) (\S+) (\S+) (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+)$/;

consumer.on('message', function (log) {

    log = log.trim();
    var parsed = log.split(regex);

    //console.log(parsed);
    parsed.splice(0, 1);
    parsed.splice(parsed.length - 1, 1);
    var result = {};

    for (var i = 0; i < fields.length; i++) {
        result[fields[i]] = parsed[i];
    }
    payloads = [
        { topic: 'TreatedWebLog', messages: result },
    ];
    producer.on('ready', function () {
        producer.send(payloads, function (data, err) {
            console.log(data);
        });
    });
});
